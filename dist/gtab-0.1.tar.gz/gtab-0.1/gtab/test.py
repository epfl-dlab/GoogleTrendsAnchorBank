from gtab import GTAB
import ast
import json
import os


def bla(ptrends_config=None, gtab_config=None, conn_config=None, blacklist=None, use_proxies=False):
    """
        Initializes the GTAB instance.

        Input parameters:
            ptrends_config - a dictionary containing the configuration parameters for the pytrends library when 
            building the payload (i.e. timeframe and geo).
            gtab_config - a dictionary containing the configuration parameters for the GTAB methodology when making
                the connection.
            conn_config - a dictionary containing the configuration parameters for the connection (e.g. proxies, 
            timeout, retries...).

        If any parameter is None, the corresponding file in the directory "./config/" is taken. It should contain a 
        single line with the corresponding config dictionary.
    """

    # START TODO: make it all one single json config and add the overwrites from the top
    if ptrends_config is None:
        with open(os.path.join("../config", "ptrends.config"), "r") as f_conf:
            PTRENDS_CONFIG = ast.literal_eval(f_conf.readline())
    else:
        PTRENDS_CONFIG = ptrends_config

    if gtab_config is None:
        with open(os.path.join("../config", "gtab.config"), "r") as f_conf:
            GTAB_CONFIG = ast.literal_eval(f_conf.readline())
    else:
        GTAB_CONFIG = gtab_config

    if conn_config is None:
        with open(os.path.join("../config", "conn.config"), "r") as f_conf:
            CONN_CONFIG = ast.literal_eval(f_conf.readline())
    else:
        CONN_CONFIG = conn_config

    if blacklist is None:
        with open(os.path.join("../config", "blacklist.config"), "r") as f_conf:
            BLACKLIST = ast.literal_eval(f_conf.readline())
    else:
        BLACKLIST = blacklist
    # END

    config = {"PTRENDS": PTRENDS_CONFIG, "GTAB": GTAB_CONFIG, "CONN": CONN_CONFIG, "BLACKLIST": BLACKLIST}
    with open("CFG.json", 'w') as fp:
        json.dump(config, fp, indent = 4, sort_keys=True)

if __name__ == "__main__":
 
    t = GTAB()
    t.init()