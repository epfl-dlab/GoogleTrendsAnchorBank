import os

package_directory = os.path.dirname(os.path.abspath(__file__))
